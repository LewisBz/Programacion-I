package com.mycompany.skysuites;

/**
 * Sistema de Gestión de Reservas Hotel SkySuites
 * Autor: Luis Grandett y Sebastian Arrieta
 */

import java.util.Scanner;  // Para leer datos desde consola
import java.util.HashMap;  // Para almacenar datos en pares clave-valor
import java.util.ArrayList; // Para almacenar listas dinámicas

// Clase que representa una reserva en el hotel
class Reserva {
    private static int contadorId = 1; // Contador para generar IDs únicos de reserva
    private int id; // ID de la reserva
    private String idCliente; // Documento o ID del cliente
    private String nombreCliente; // Nombre completo del cliente
    private String empresaNIT; // NIT de la empresa asociada
    private String nombreEmpresa; // Nombre de la empresa asociada
    private int tipoHabitacion; // Tipo de habitación (1, 2 o 3)
    private int numeroNoches; // Cantidad de noches reservadas
    private String fechaReserva; // Fecha en formato DD/MM/AAAA
    private double valorTotal; // Valor total de la reserva
    private boolean descuentoAplicado; // Indica si se aplicó un descuento

    // Constructor: recibe los datos de la reserva y calcula el total
    public Reserva(String idCliente, String nombreCliente, String empresaNIT, 
                   String nombreEmpresa, int tipoHabitacion, int numeroNoches, String fechaReserva) {
        this.id = contadorId++; // Asigna ID único y aumenta el contador
        this.idCliente = idCliente; // Guarda ID cliente
        this.nombreCliente = nombreCliente; // Guarda nombre cliente
        this.empresaNIT = empresaNIT; // Guarda NIT empresa
        this.nombreEmpresa = nombreEmpresa; // Guarda nombre empresa
        this.tipoHabitacion = tipoHabitacion; // Guarda tipo habitación
        this.numeroNoches = numeroNoches; // Guarda número de noches
        this.fechaReserva = fechaReserva; // Guarda fecha
        this.descuentoAplicado = false; // Inicialmente no tiene descuento
        calcularValorTotal(); // Calcula el valor total
    }
    
    // Calcula el valor total según el tipo de habitación y noches
    private void calcularValorTotal() {
        double[] precios = {250000.0, 350000.0, 800000.0}; // Precios por tipo de habitación
        this.valorTotal = precios[tipoHabitacion - 1] * numeroNoches; // Precio * noches
    }
    
    // Aplica un descuento del 10% si aún no ha sido aplicado
    public void aplicarDescuento() {
        if (!descuentoAplicado) {
            this.valorTotal = this.valorTotal * 0.9; // Aplica descuento
            this.descuentoAplicado = true; // Marca que el descuento está aplicado
        }
    }
    
    // Quita el descuento si estaba aplicado
    public void quitarDescuento() {
        if (descuentoAplicado) {
            this.valorTotal = this.valorTotal / 0.9; // Revierte el descuento
            this.descuentoAplicado = false; // Marca que no tiene descuento
        }
    }
    
    // Métodos getters (devuelven valores de los atributos)
    public int getId() { return id; }
    public String getIdCliente() { return idCliente; }
    public String getNombreCliente() { return nombreCliente; }
    public String getEmpresaNIT() { return empresaNIT; }
    public String getNombreEmpresa() { return nombreEmpresa; }
    public int getTipoHabitacion() { return tipoHabitacion; }
    public int getNumeroNoches() { return numeroNoches; }
    public String getFechaReserva() { return fechaReserva; }
    public double getValorTotal() { return valorTotal; }
    public boolean isDescuentoAplicado() { return descuentoAplicado; }
    
    // Devuelve el nombre del tipo de habitación en texto
    public String getNombreTipoHabitacion() {
        String[] tipos = {"Estandar", "Ejecutiva", "Suite Presidencial"};
        return tipos[tipoHabitacion - 1];
    }
    
    // Devuelve la información de la reserva en formato legible
    public String toString() {
        return "ID: " + id + " | Cliente: " + nombreCliente + " (ID: " + idCliente + 
               ") | Empresa: " + nombreEmpresa + " (NIT: " + empresaNIT + 
               ") | Habitacion: " + getNombreTipoHabitacion() + " | Noches: " + numeroNoches + 
               " | Fecha: " + fechaReserva + " | Total: $" + (int)valorTotal + 
               (descuentoAplicado ? " (Descuento 10%)" : "");
    }
}

public class SkySuites {
    
    private static Scanner read = new Scanner(System.in); // Lector de entrada de datos
    
    // Estructuras para manejar reservas
    private static HashMap<String, ArrayList<Reserva>> reservasPorFecha = new HashMap<>(); // Fecha -> Lista de reservas
    private static HashMap<String, Integer> reservasPorEmpresaHoy = new HashMap<>(); // Empresa-fecha -> Cantidad reservas
    private static ArrayList<Reserva> todasLasReservas = new ArrayList<>(); // Lista de todas las reservas
    
    public static void main(String[] args) {
        int opcion;
        do {
            mostrarMenu(); // Muestra el menú
            opcion = leerOpcion(); // Lee la opción seleccionada
            
            // Ejecuta la acción según la opción
            switch (opcion) {
                case 1 -> registrarReserva();
                case 2 -> mostrarTodasLasReservas();
                case 3 -> cancelarReservaPorId();
                case 4 -> mostrarTotalFacturadoDia();
                case 5 -> System.out.println("\nGracias por usar el sistema SkySuites!");
                default -> System.out.println("\nOpcion invalida. Intente nuevamente.");
            }
        } while (opcion != 5); // Repite hasta que el usuario elija salir
        
        read.close(); // Cierra el scanner
    }
    
    // Muestra el menú de opciones
    private static void mostrarMenu() {
        System.out.println("\n=====================================");
        System.out.println("  SISTEMA RESERVAS HOTEL SKYSUITES");
        System.out.println("=====================================");
        System.out.println("1. Registrar nueva reserva");
        System.out.println("2. Mostrar todas las reservas");
        System.out.println("3. Cancelar reserva por ID");
        System.out.println("4. Mostrar total facturado del dia");
        System.out.println("5. Salir");
        System.out.println("=====================================");
        System.out.print("Seleccione opcion (1-5): ");
    }
    
    // Lee y valida la opción seleccionada
    private static int leerOpcion() {
        try {
            return Integer.parseInt(read.nextLine().trim()); // Convierte a entero
        } catch (Exception e) {
            return -1; // Retorna -1 si hay error
        }
    }
    
    // Registra una nueva reserva
    private static void registrarReserva() {
        System.out.println("\n=== REGISTRAR NUEVA RESERVA ===");
        
        try {
            // Solicita ID cliente
            System.out.print("ID del cliente: ");
            String idCliente = read.nextLine().trim();
            if (idCliente.isEmpty()) {
                System.out.println("Error: El ID del cliente no puede estar vacio.");
                return;
            }
            
            // Solicita nombre cliente
            System.out.print("Nombre del cliente: ");
            String nombreCliente = read.nextLine().trim();
            if (nombreCliente.isEmpty()) {
                System.out.println("Error: El nombre del cliente no puede estar vacio.");
                return;
            }
            
            // Solicita NIT empresa
            System.out.print("NIT de la empresa: ");
            String empresaNIT = read.nextLine().trim();
            if (empresaNIT.isEmpty()) {
                System.out.println("Error: El NIT de la empresa no puede estar vacio.");
                return;
            }
            
            // Solicita nombre empresa
            System.out.print("Nombre de la empresa: ");
            String nombreEmpresa = read.nextLine().trim();
            if (nombreEmpresa.isEmpty()) {
                System.out.println("Error: El nombre de la empresa no puede estar vacio.");
                return;
            }
            
            // Muestra tipos de habitación
            mostrarTiposHabitacion();
            System.out.print("Tipo de habitacion (1-3): ");
            int tipoHabitacion = Integer.parseInt(read.nextLine().trim());
            if (tipoHabitacion < 1 || tipoHabitacion > 3) {
                System.out.println("Error: Tipo de habitacion invalido. Debe ser 1, 2 o 3.");
                return;
            }
            
            // Solicita número de noches
            System.out.print("Numero de noches: ");
            int numeroNoches = Integer.parseInt(read.nextLine().trim());
            if (numeroNoches <= 0) {
                System.out.println("Error: El numero de noches debe ser mayor a 0.");
                return;
            }
            if (numeroNoches > 10) {
                System.out.println("Error: No se aceptan reservas de mas de 10 noches.");
                return;
            }
            
            // Solicita fecha
            System.out.print("Fecha para la reserva (DD/MM/AAAA): ");
            String fechaReserva = read.nextLine().trim();
            if (fechaReserva.isEmpty()) {
                System.out.println("Error: La fecha no puede estar vacia.");
                return;
            }
            
            // Verifica límite de reservas diarias
            if (!puedeHacerReserva(fechaReserva)) {
                System.out.println("Error: No se pueden hacer mas reservas para la fecha " + fechaReserva);
                System.out.println("Limite de 20 reservas diarias alcanzado.");
                return;
            }
            
            // Crea nueva reserva
            Reserva nuevaReserva = new Reserva(idCliente, nombreCliente, empresaNIT, 
                                             nombreEmpresa, tipoHabitacion, numeroNoches, fechaReserva);
            
            // Guarda la reserva
            agregarReserva(nuevaReserva, fechaReserva);
            // Aplica descuentos si corresponde
            verificarYAplicarDescuento(empresaNIT, fechaReserva);
            
            // Muestra confirmación
            System.out.println("\nReserva registrada exitosamente:");
            System.out.println(nuevaReserva);
            
        } catch (Exception e) {
            System.out.println("Error: Datos invalidos. " + e.getMessage());
        }
    }

    
       // Muestra los tipos de habitación y sus precios
    private static void mostrarTiposHabitacion() {
        System.out.println("\nTipos de habitacion:");
        System.out.println("1. Estandar - $250,000 por noche");       // Tipo 1
        System.out.println("2. Ejecutiva - $350,000 por noche");      // Tipo 2
        System.out.println("3. Suite Presidencial - $800,000 por noche"); // Tipo 3
    }
    
    // Verifica si aún se puede hacer una reserva en una fecha (máximo 20 por día)
    private static boolean puedeHacerReserva(String fecha) {
        ArrayList<Reserva> reservasFecha = reservasPorFecha.get(fecha); // Busca reservas de la fecha
        return reservasFecha == null || reservasFecha.size() < 20; // Si no hay reservas o son menos de 20, se puede
    }
    
    // Guarda la reserva en las estructuras de datos
    private static void agregarReserva(Reserva reserva, String fecha) {
        // Agrega a la lista por fecha (si no existe, crea una nueva lista)
        reservasPorFecha.computeIfAbsent(fecha, k -> new ArrayList<>()).add(reserva);
        
        // Agrega a la lista general
        todasLasReservas.add(reserva);
        
        // Crea clave "empresaNIT-fecha" para contar reservas de esa empresa ese día
        String claveEmpresaFecha = reserva.getEmpresaNIT() + "-" + fecha;
        reservasPorEmpresaHoy.put(claveEmpresaFecha, reservasPorEmpresaHoy.getOrDefault(claveEmpresaFecha, 0) + 1);
    }
    
    // Verifica si una empresa tiene 5 o más reservas para un día y aplica descuento a todas
    private static void verificarYAplicarDescuento(String empresaNIT, String fecha) {
        String claveEmpresaFecha = empresaNIT + "-" + fecha; // Clave única para la empresa en esa fecha
        Integer cantidadReservas = reservasPorEmpresaHoy.get(claveEmpresaFecha); // Cantidad actual de reservas
        
        if (cantidadReservas != null && cantidadReservas >= 5) { // Si son 5 o más
            ArrayList<Reserva> reservasFecha = reservasPorFecha.get(fecha); // Obtiene todas las reservas de ese día
            if (reservasFecha != null) {
                for (Reserva r : reservasFecha) { // Recorre cada reserva
                    if (r.getEmpresaNIT().equals(empresaNIT)) { // Si es de la empresa
                        r.aplicarDescuento(); // Aplica descuento del 10%
                    }
                }
                System.out.println("\nDescuento del 10% aplicado!");
                System.out.println("La empresa tiene 5 o mas reservas para la fecha " + fecha);
            }
        }
    }
    
    // Muestra todas las reservas registradas
    private static void mostrarTodasLasReservas() {
        System.out.println("\n=== TODAS LAS RESERVAS ===");
        
        if (todasLasReservas.isEmpty()) { // Si no hay reservas
            System.out.println("No hay reservas registradas.");
            return;
        }
        
        System.out.println("Total de reservas: " + todasLasReservas.size()); // Cantidad total
        System.out.println();
        
        double totalGeneral = 0; // Acumulador de dinero total
        for (Reserva reserva : todasLasReservas) { // Recorre todas las reservas
            System.out.println(reserva); // Muestra información
            totalGeneral += reserva.getValorTotal(); // Suma al total
        }
        
        System.out.println("\nTOTAL GENERAL: $" + (int)totalGeneral); // Muestra total general
    }
    
    // Cancela una reserva por su ID
    private static void cancelarReservaPorId() {
        System.out.println("\n=== CANCELAR RESERVA ===");
        
        if (todasLasReservas.isEmpty()) { // Si no hay reservas
            System.out.println("No hay reservas para cancelar.");
            return;
        }
        
        try {
            System.out.print("Ingrese el ID de la reserva a cancelar: ");
            int idReserva = Integer.parseInt(read.nextLine().trim()); // Lee ID
            
            Reserva reservaEncontrada = null; // Variable para guardar la reserva encontrada
            
            // Busca la reserva en la lista general
            for (Reserva r : todasLasReservas) {
                if (r.getId() == idReserva) {
                    reservaEncontrada = r;
                    break; // Sale del bucle si la encuentra
                }
            }
            
            if (reservaEncontrada == null) { // Si no existe el ID
                System.out.println("Error: No se encontro una reserva con ID " + idReserva);
                return;
            }
            
            // Muestra la reserva encontrada
            System.out.println("\nReserva encontrada:");
            System.out.println(reservaEncontrada);
            
            // Confirma si se desea cancelar
            System.out.print("\nEsta seguro de cancelar esta reserva? (S/N): ");
            String confirmacion = read.nextLine().trim().toUpperCase();
            
            if (!confirmacion.equals("S")) { // Si no confirma con S
                System.out.println("Cancelacion abortada.");
                return;
            }
            
            // Elimina de la lista general
            todasLasReservas.remove(reservaEncontrada);
            
            // Elimina de la lista por fecha
            String fecha = reservaEncontrada.getFechaReserva();
            ArrayList<Reserva> reservasFecha = reservasPorFecha.get(fecha);
            if (reservasFecha != null) {
                reservasFecha.remove(reservaEncontrada);
                if (reservasFecha.isEmpty()) { // Si queda vacía, elimina la clave de fecha
                    reservasPorFecha.remove(fecha);
                }
            }
            
            // Actualiza el conteo por empresa
            String claveEmpresaFecha = reservaEncontrada.getEmpresaNIT() + "-" + fecha;
            Integer contador = reservasPorEmpresaHoy.get(claveEmpresaFecha);
            if (contador != null && contador > 1) {
                reservasPorEmpresaHoy.put(claveEmpresaFecha, contador - 1); // Resta 1
            } else {
                reservasPorEmpresaHoy.remove(claveEmpresaFecha); // Elimina si ya no hay
            }
            
            // Recalcula descuentos para esa empresa en esa fecha
            recalcularDescuentos(reservaEncontrada.getEmpresaNIT(), fecha);
            
            System.out.println("Reserva cancelada exitosamente.");
            
        } catch (Exception e) {
            System.out.println("Error: ID invalido. Debe ser un numero.");
        }
    }
    
    // Recalcula descuentos de una empresa en una fecha
    private static void recalcularDescuentos(String empresaNIT, String fecha) {
        String claveEmpresaFecha = empresaNIT + "-" + fecha;
        Integer cantidadReservas = reservasPorEmpresaHoy.get(claveEmpresaFecha);
        
        // Si la empresa ya no cumple los 5 mínimos, quita el descuento a sus reservas
        if (cantidadReservas == null || cantidadReservas < 5) {
            ArrayList<Reserva> reservasFecha = reservasPorFecha.get(fecha);
            if (reservasFecha != null) {
                for (Reserva r : reservasFecha) {
                    if (r.getEmpresaNIT().equals(empresaNIT) && r.isDescuentoAplicado()) {
                        r.quitarDescuento(); // Quita descuento
                    }
                }
            }
        }
    }
    
    // Muestra el total facturado en un día específico
    private static void mostrarTotalFacturadoDia() {
        System.out.println("\n=== TOTAL FACTURADO POR DIA ===");
        
        if (reservasPorFecha.isEmpty()) { // Si no hay reservas en ninguna fecha
            System.out.println("No hay reservas registradas.");
            return;
        }
        
        System.out.print("Ingrese la fecha (DD/MM/AAAA): ");
        String fecha = read.nextLine().trim();
        
        ArrayList<Reserva> reservasFecha = reservasPorFecha.get(fecha); // Obtiene reservas de la fecha
        
        if (reservasFecha == null || reservasFecha.isEmpty()) { // Si no hay reservas ese día
            System.out.println("No hay reservas para la fecha " + fecha);
            return;
        }
        
        // Muestra listado de reservas de ese día
        System.out.println("\nReservas para la fecha: " + fecha);
        System.out.println("Numero de reservas: " + reservasFecha.size());
        System.out.println();
        
        double totalDia = 0; // Acumulador de total diario
        for (Reserva reserva : reservasFecha) {
            System.out.println("- " + reserva.getNombreCliente() + ": $" + (int)reserva.getValorTotal() +
                             (reserva.isDescuentoAplicado() ? " (con descuento)" : ""));
            totalDia += reserva.getValorTotal();
        }
        
        // Muestra total del día
        System.out.println("\nTOTAL FACTURADO EL DIA " + fecha + ": $" + (int)totalDia);
    }
}
