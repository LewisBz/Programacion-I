package com.mycompany.skysuites;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * Sistema de gestion de reservas para el Hotel Empresarial SkySuites
 * Permite registrar, calcular y mostrar reservas de habitaciones corporativas
 * @author Sebastian Arrieta y Luis Grandett
 */

//Clase que representa una reserva individual
class Reserva {
    int id;
    String nombreCliente;
    String empresa;
    String nitEmpresa; 
    int tipoHabitacion;
    int numeroNoches;
    double valorTotal;
    String fechaInicio; 
    static int contadorId = 1;
    
    // Constructor que asigna ID automáticamente
    public Reserva() {
        this.id = contadorId++;
    }
    
    // Método para calcular el valor total según tipo de habitación y noches
    public void calcularTotal() {
        double precioPorNoche = 0;
        
        switch(tipoHabitacion) {
            case 1: // Estandar
                precioPorNoche = 250000;
                break;
            case 2: // Ejecutiva
                precioPorNoche = 350000;
                break;
            case 3: // Suite Presidencial
                precioPorNoche = 800000;
                break;
        }
        
        valorTotal = precioPorNoche * numeroNoches;
    }
    
    // Método para aplicar descuento del 10%
    public void aplicarDescuento() {
        valorTotal = valorTotal * 0.9;
    }
    
    // Método para obtener nombre del tipo de habitación
    public String getNombreTipoHabitacion() {
        switch(tipoHabitacion) {
            case 1: return "Estandar";
            case 2: return "Ejecutiva";
            case 3: return "Suite Presidencial";
            default: return "Error. Seleccione una valida";
        }
    }
}

//Clase principal que maneja el sistema de reservas
class HOTEL {
    ArrayList<Reserva> reservas=new ArrayList<Reserva>();
    Scanner scanner=new Scanner(System.in);
    
    //Método que permite agregar una nueva reserva
    public void agregarReserva() {
        Reserva reserva=new Reserva();
        
        //  Identificación de la empresa
        System.out.println("================================");
        System.out.println("IDENTIFICACION EMPRESARIAL");
        System.out.println("================================");
        
        System.out.print("NIT de la empresa: ");
        reserva.nitEmpresa = scanner.nextLine();
        
        System.out.print("Nombre de la empresa: ");
        reserva.empresa = scanner.nextLine();
        
        // Datos del cliente
        System.out.println("================================");
        System.out.println("DATOS DEL CLIENTE");
        System.out.println("================================");
        
        System.out.print("Nombre completo del cliente: ");
        reserva.nombreCliente = scanner.nextLine();
        
        //  Fecha de la reserva
        System.out.println("================================");
        System.out.println("FECHA DE LA RESERVA");
        System.out.println("================================");
        
        System.out.print("Fecha de inicio de la reserva (ejemplo: Lunes, Martes, etc.): ");
        reserva.fechaInicio = scanner.nextLine();
        
        // Verifica el limite de 20 reservas para esa fecha
        int reservasEnFecha = contarReservasEnFecha(reserva.fechaInicio);
        if(reservasEnFecha >= 20) {
            System.out.println("=====================================");
            System.out.println("LIMITE DIARIO ALCANZADO");
            System.out.println("=====================================");
            System.out.println("No se pueden realizar más reservas para el " + reserva.fechaInicio);
            System.out.println("LImite maximo: 20 reservas por dia");
            System.out.println("Reservas actuales para " + reserva.fechaInicio + ": " + reservasEnFecha);
            System.out.println("=====================================");
            return;
        }
        
        // Bloque de codigo que ayuda a la seleccion de la habitacion
        System.out.println("================================");
        System.out.println("SELECCION DE HABITACION");
        System.out.println("================================");
        
        mostrarTiposHabitacion();
        
        boolean tipoValido = false;
        while(!tipoValido) {
            System.out.print("Ingrese el numero del tipo de habitación (1, 2 o 3): ");
            reserva.tipoHabitacion = scanner.nextInt();
            
            if(reserva.tipoHabitacion >= 1 && reserva.tipoHabitacion <= 3) {
                tipoValido = true;
            } else {
                System.out.println("Debe ingresar solo 1, 2 o 3");
            }
        }
        
        // Validar número de noches
        boolean nochesValidas=false;
        while(!nochesValidas) {
            System.out.print("Numero de noches (maximo 10 para un solo cliente): ");
            reserva.numeroNoches = scanner.nextInt();
            
            if(reserva.numeroNoches>=1 && reserva.numeroNoches<=10) {
                nochesValidas=true;
            } else {
                System.out.println(" Debe ingresar un numero entre 1 y 10 noches");
                System.out.println(" El hotel no acepta reservas de más de 10 noches para un solo cliente");
            }
        }
        
        scanner.nextLine(); // Limpiar buffer
        reserva.calcularTotal();
        
        // Verificar si la empresa tiene 5 o más reservas previas
        int reservasEmpresaPrevias=0;
        for(int i=0; i<reservas.size(); i++) {
            if(reservas.get(i).nitEmpresa.equalsIgnoreCase(reserva.nitEmpresa)) {
                reservasEmpresaPrevias++;
            }
        }
        //Bloque de codigo que valida el descuento
        boolean descuentoAplicado = false;
        if(reservasEmpresaPrevias >= 5) {
            reserva.aplicarDescuento();
            descuentoAplicado = true;
        }
        
        reservas.add(reserva);
        // Bloque de codigo muestra la reserva a sido guardada
        System.out.println("================================");
        System.out.println("RESERVA REGISTRADA EXITOSAMENTE");
        System.out.println("================================");
        System.out.println("ID de reserva: " + reserva.id);
        System.out.println("--- DATOS EMPRESARIALES ---");
        System.out.println("NIT: " + reserva.nitEmpresa);
        System.out.println("Empresa: " + reserva.empresa);
        System.out.println("--- DATOS DEL CLIENTE ---");
        System.out.println("Cliente: " + reserva.nombreCliente);
        System.out.println("--- DETALLES DE LA RESERVA ---");
        System.out.println("Fecha de inicio: " + reserva.fechaInicio);
        System.out.println("Tipo de habitacion: " + reserva.getNombreTipoHabitacion());
        System.out.println("Número de noches: " + reserva.numeroNoches);
        if(descuentoAplicado) {
            System.out.println("Descuento del 10% aplicado por hacer mas de 5 reservas");
            System.out.println("(La empresa " + reserva.empresa + " tiene " + reservasEmpresaPrevias + " reservas previas)");
        }
        System.out.println("Valor total: $" + (int)reserva.valorTotal);
        System.out.println("Disponibilidad restante para " + reserva.fechaInicio + ": " + (19 - reservasEnFecha) + "/20");
        System.out.println("================================");
    }
    
    // Método para contar reservas en una fecha
    private int contarReservasEnFecha(String fecha) {
        int contador = 0;
        for(int i = 0;i<reservas.size(); i++) {
            if(reservas.get(i).fechaInicio.equalsIgnoreCase(fecha)) {
                contador++;
            }
        }
        return contador;
    }
    
    // Mostrar tipos de habitación
    public void mostrarTiposHabitacion() {
        System.out.println("================================");
        System.out.println("TIPOS DE HABITACION Y TARIFAS");
        System.out.println("================================");
        System.out.println("1. Estandar-$250000 por noche");
        System.out.println("2. Ejecutiva-$350000 por noche");
        System.out.println("3. Suite Presidencial-$800000 por noche");
        System.out.println("================================");
    }
    
    // Mostrar todas las reservas
    public void mostrarReservas() {
        if(reservas.size()==0) {
            System.out.println("No hay reservas registradas");
            return;
        }
        
        for(int i = 0; i<reservas.size(); i++) {
            System.out.println("================================");
            System.out.println("--- Reserva "+ (i+1)+" ---");
            System.out.println("================================");
            System.out.println("ID: " + reservas.get(i).id);
            System.out.println("--- DATOS EMPRESARIALES ---");
            System.out.println("NIT: " + reservas.get(i).nitEmpresa);
            System.out.println("Empresa: " + reservas.get(i).empresa);
            System.out.println("--- DATOS DEL CLIENTE ---");
            System.out.println("Cliente: " + reservas.get(i).nombreCliente);
            System.out.println("--- DETALLES DE LA RESERVA ---");
            System.out.println("Habitacion: " + reservas.get(i).getNombreTipoHabitacion());
            System.out.println("Noches: " + reservas.get(i).numeroNoches);
            System.out.println("Valor total: $" + (int)reservas.get(i).valorTotal);
            System.out.println("Fecha de inicio: " + reservas.get(i).fechaInicio);
        }
        System.out.println("================================");
        System.out.println("Total de reservas: " + reservas.size());
    }
    
    // Cancelar reserva
    public void cancelarReserva() {
        if(reservas.size()==0) {
            System.out.println("No hay reservas para cancelar");
            return;
        }
        
        System.out.print("Ingrese el ID de la reserva a cancelar: ");
        int idCancelar = scanner.nextInt();
        scanner.nextLine(); 
        
        boolean encontrada = false;
        for(int i = 0; i<reservas.size(); i++) {
            if(reservas.get(i).id == idCancelar) {
                System.out.println("================================");
                System.out.println("RESERVA CANCELADA");
                System.out.println("================================");
                System.out.println("Cliente: " + reservas.get(i).nombreCliente);
                System.out.println("Empresa: " + reservas.get(i).empresa + " (NIT: " + reservas.get(i).nitEmpresa + ")");
                System.out.println("Fecha: " + reservas.get(i).fechaInicio);
                System.out.println("Habitación: " + reservas.get(i).getNombreTipoHabitacion());
                System.out.println("================================");
                reservas.remove(i);
                encontrada = true;
                break;
            }
        }
        
        if(!encontrada) {
            System.out.println("No se encontró una reserva con ese ID");
        }
    }
    
    // Mostrar total facturado
    public void mostrarTotalFacturado() {
        double totalFacturado=0;
        int totalReservas=reservas.size();
        
        int contadorEstandar=0,contadorEjecutiva=0,contadorSuite=0;
        double totalEstandar=0,totalEjecutiva=0,totalSuite=0;
        
        for(int i = 0;i<reservas.size(); i++) {
            totalFacturado+=reservas.get(i).valorTotal;
            
            switch(reservas.get(i).tipoHabitacion) {
                case 1:
                    contadorEstandar++;
                    totalEstandar+=reservas.get(i).valorTotal;
                    break;
                case 2:
                    contadorEjecutiva++;
                    totalEjecutiva+=reservas.get(i).valorTotal;
                    break;
                case 3:
                    contadorSuite++;
                    totalSuite += reservas.get(i).valorTotal;
                    break;
            }
        }
        
        System.out.println("================================");
        System.out.println("TOTAL FACTURADO DEL DIA");
        System.out.println("================================");
        System.out.println("Total de reservas: " + totalReservas);
        System.out.println("Total facturado: $" + (int)totalFacturado);
        System.out.println("");
        System.out.println("Desglose por tipo:");
        System.out.println("- Estandar: " + contadorEstandar + " reservas - $" + (int)totalEstandar);
        System.out.println("- Ejecutiva: " + contadorEjecutiva + " reservas - $" + (int)totalEjecutiva);
        System.out.println("- Suite Presidencial: " + contadorSuite + " reservas - $" + (int)totalSuite);
        System.out.println("================================");
    }
    
    // Bloque de codigo que muestra la disponibilidad por día
    public void mostrarDisponibilidadPorDia() {
        System.out.println("================================");
        System.out.println("DISPONIBILIDAD POR DIA");
        System.out.println("================================");

        ArrayList<String> diasConReservas = new ArrayList<String>();
        for(int i = 0; i < reservas.size(); i++) {
            String fecha = reservas.get(i).fechaInicio;
            if(!diasConReservas.contains(fecha)) {
                diasConReservas.add(fecha);
            }
        }
        
        if(diasConReservas.size() == 0) {
            System.out.println("No hay reservas registradas aún");
        } else {
            for(String dia:diasConReservas) {
                int reservasEnDia=contarReservasEnFecha(dia);
                int disponibles =20-reservasEnDia;
                System.out.println(dia+": " +reservasEnDia + "/20 reservas (" + disponibles + " disponibles)");
            }
        }
        System.out.println("================================");
    }
    
    // Bloque de codigo que muestra el menu al usuario
    public void menu() {
        int opcion = 0;
        while(opcion != 7) {
            System.out.println("================================");
            System.out.println("HOTEL EMPRESARIAL SKYSUITES");
            System.out.println("Sistema de Gestion de Reservas");
            System.out.println("================================");
            System.out.println("1. Registrar nueva reserva");
            System.out.println("2. Mostrar todas las reservas");
            System.out.println("3. Cancelar reserva por ID");
            System.out.println("4. Mostrar total facturado del dia");
            System.out.println("5. Mostrar tipos de habitacion");
            System.out.println("6. Ver disponibilidad por dia");
            System.out.println("7. Salir del programa");
            System.out.println("");
            System.out.print("Escoja una opcion: ");
            
            opcion = scanner.nextInt();
            scanner.nextLine();
            
            if(opcion<1||opcion>7) {
                System.out.println("Ingrese un numero valido para el menu ");
                continue;
            }
            
            if(opcion==1) agregarReserva();
            if(opcion==2) mostrarReservas();
            if(opcion==3) cancelarReserva();
            if(opcion==4) mostrarTotalFacturado();
            if(opcion==5) mostrarTiposHabitacion();
            if(opcion==6) mostrarDisponibilidadPorDia();
            if(opcion==7) {
                System.out.println("Gracias por usar el sistema de Reservas SkySuites");
                System.out.println("Que tenga un excelente dia");
            }
        }
    }
}

// Inicializacion del menu
public class Skysuites {
    public static void main(String[] args) {
        HOTEL skysuites = new HOTEL();
        skysuites.menu();
    }
}
