/*
 * Sistema de gestión para Pizzería COMA RICO
 * Permite manejar pedidos, clientes, facturación y reportes de ventas
 * 
 * @author Luis Grandett
 */
package com.mycompany.pizzeriacomarico;

import java.util.HashMap;  // Para almacenar el menú (producto -> precio)
import java.util.Scanner;  
import java.util.ArrayList; // Para listas dinámicas de clientes, pedidos, items

/**
 * CLASE ItemPedido - Representa un producto específico dentro de un pedido
 * Contiene: producto, cantidad y calcula subtotal
 */
class ItemPedido {
    private String nombreProducto; // Nombre del producto pedido
    private double precio;         // Precio unitario del producto
    private int cantidad;          // Cantidad solicitada
    
    // Constructor: crea un item de pedido con producto, precio y cantidad
    public ItemPedido(String nombreProducto, double precio, int cantidad) {
        this.nombreProducto = nombreProducto; 
        this.precio = precio;                 
        this.cantidad = cantidad;             
    }
    
    public String getNombreProducto() { return nombreProducto; }
    public double getPrecio() { return precio; }
    public int getCantidad() { return cantidad; }
    public double getSubtotal() { return precio * cantidad; }
}

/**
 * CLASE Pedido - Representa un pedido completo de un cliente
 * Contiene: lista de items, número de pedido único y cálculo de total
 */
class Pedido {
    private ArrayList<ItemPedido> items;     
    private static int contadorPedidos = 1;  // Contador estático para numerar pedidos
    private int numeroPedido;                // Número único de este pedido
    
    // Constructor: inicializa un nuevo pedido vacío
    public Pedido() {
        this.items = new ArrayList<>();          // Crea lista vacía de items
        this.numeroPedido = contadorPedidos++;   
    }
    
    public void agregarItem(ItemPedido item) {
        items.add(item); 
    }
    
    // Getter: devuelve la lista completa de items
    public ArrayList<ItemPedido> getItems() {
        return items;
    }
    
    // Getter: devuelve el número único del pedido
    public int getNumeroPedido() {
        return numeroPedido;
    }
    
    // Método: calcula el total del pedido sumando todos los subtotales
    public double getTotal() {
        double total = 0;                    // Inicializa acumulador
        for (ItemPedido item : items) {      // Recorre cada item
            total += item.getSubtotal();     // Suma el subtotal de cada item
        }
        return total; 
    }
}

/**
 * CLASE Cliente - Representa un cliente que puede tener múltiples pedidos
 * Contiene: nombre del cliente y lista de todos sus pedidos
 */
class Cliente {
    private String nombre;                    // Nombre del cliente
    private ArrayList<Pedido> pedidos;        // Lista de pedidos del cliente
    
    // Constructor: crea un nuevo cliente
    public Cliente(String nombre) {
        this.nombre = nombre;                 // Asigna el nombre
        this.pedidos = new ArrayList<>();     // Inicializa lista vacía de pedidos
    }
    
    // Getter: devuelve el nombre del cliente
    public String getNombre() {
        return nombre;
    }
    
    // Método: agrega un pedido a la lista del cliente
    public void agregarPedido(Pedido pedido) {
        pedidos.add(pedido); // Añade el pedido a la lista
    }
    
    // Getter: devuelve todos los pedidos del cliente
    public ArrayList<Pedido> getPedidos() {
        return pedidos;
    }
    
    // Método: calcula el total gastado por el cliente en todos sus pedidos
    public double getTotalCliente() {
        double total = 0;                    // Inicializa acumulador
        for (Pedido pedido : pedidos) {      // Recorre cada pedido del cliente
            total += pedido.getTotal();      // Suma el total de cada pedido
        }
        return total; // Devuelve el total gastado por el cliente
    }
}

public class PizzeriaComaRico {
    private static HashMap<String, Double> menuPizzeria = new HashMap<>();
    private static ArrayList<Cliente> clientes = new ArrayList<>();
    private static Scanner read = new Scanner(System.in);
    
    public static void main(String[] args) { //MAIN
        inicializarMenu(); 
        
        
        System.out.println("=== BIENVENIDO A PIZZERIA COMA RICO ===\n");
        
        boolean continuar = true; 
        while (continuar) { // Bucle principal del sistema
            mostrarMenuPrincipal(); // Muestra las opciones disponibles
            int opcion = leerEntero("Seleccione una opcion: "); 
            
            // Switch para manejar cada opción del menú
            switch (opcion) {
                case 1 -> 
                    atenderCliente();
                case 2 -> 
                    mostrarVentaTotalDiaria();
                case 3 -> 
                    mostrarVentasPorPizza();
                case 4 -> 
                    mostrarHistorialClientes();
                case 5 -> {
                    // Opción: Salir del sistema
                    continuar = false; // Termina el bucle
                    System.out.println("Gracias por usar el sistema de PIZZERIA COMA RICO!");
                }
                default -> // Opción inválida
                    System.out.println("Opcion invalida. Por favor intente nuevamente.");
            }
        }
    }
    
    /**
     * MÉTODO inicializarMenu - Carga el menú inicial en el HashMap
     * Usa la estructura clave-valor: nombre del producto -> precio
     */
    private static void inicializarMenu() {
        menuPizzeria.put("Pizza de jamon y queso", 28000.0);    
        menuPizzeria.put("Pizza Hawaiana", 35000.0);            
        menuPizzeria.put("Pizza Napolitana", 30000.0);          
        menuPizzeria.put("Pizza Queso y Pepperoni", 45000.0);   
        menuPizzeria.put("Gaseosa", 5500.0);                    
    }
    
    /**
     * MÉTODO mostrarMenuPrincipal - Muestra las opciones del sistema
     * Interface principal para el usuario
     */
    private static void mostrarMenuPrincipal() {
        System.out.println("\n=== MENU PRINCIPAL ===");
        System.out.println("1. Atender nuevo cliente");       
        System.out.println("2. Ver venta total diaria");      
        System.out.println("3. Ver ventas por tipo de pizza"); 
        System.out.println("4. Ver historial de clientes");   
        System.out.println("5. Salir");                       
    }
    
    /**
     * MÉTODO mostrarMenuProductos - Muestra todos los productos disponibles
     * Usa el HashMap para mostrar dinámicamente los productos
     */
    private static void mostrarMenuProductos() {
        System.out.println("\n=== MENU DE PRODUCTOS ===");
        int opcion = 1; // Contador para numerar las opciones
        
        // Itera sobre todas las claves (nombres) del HashMap
        for (String nombreProducto : menuPizzeria.keySet()) {
            double precio = menuPizzeria.get(nombreProducto); // Obtiene precio usando la clave
            // Imprime: número, nombre y precio formateado
            System.out.println(opcion + ". " + nombreProducto + " - $" + String.format("%,.0f", precio));
            opcion++; // Incrementa contador para siguiente producto
        }
    }
    
    /**
     * MÉTODO atenderCliente - Gestiona todo el proceso de atención al cliente
     * Permite crear cliente nuevo o buscar existente, y manejar múltiples pedidos
     */
    private static void atenderCliente() {
        // Solicita el nombre del cliente
        System.out.print("Ingrese el nombre del cliente: ");
        String nombreCliente = read.nextLine(); // Lee el nombre completo
        
        // Busca si el cliente ya existe en el sistema
        Cliente cliente = buscarCliente(nombreCliente);
        if (cliente == null) { // Si no existe
            cliente = new Cliente(nombreCliente); // Crea nuevo cliente
            clientes.add(cliente);                 // Lo agrega a la lista
            System.out.println("Cliente registrado exitosamente.");
        } else { // Si ya existe
            System.out.println("Cliente encontrado. Agregando nuevo pedido.");
        }
        
        boolean continuarPedidos = true; // Control para múltiples pedidos
        while (continuarPedidos) {       // Bucle para pedidos del cliente
            Pedido pedido = crearPedido(); // Crea un nuevo pedido
            if (!pedido.getItems().isEmpty()) { // Si el pedido tiene items
                cliente.agregarPedido(pedido);     // Agrega pedido al cliente
                mostrarComanda(cliente, pedido);   // Muestra la comanda
                mostrarFactura(cliente, pedido);   // Genera la factura
            }
            
            // Pregunta si quiere hacer otro pedido
            continuarPedidos = preguntarSiNo("¿Desea realizar otro pedido para este cliente? (s/n): ");
        }
    }
    
    /**
     * MÉTODO crearPedido - Crea un nuevo pedido permitiendo agregar múltiples productos
     * Usa HashMap para buscar productos y precios
     */
    private static Pedido crearPedido() {
        Pedido pedido = new Pedido(); // Crea pedido vacío
        boolean continuarItems = true; // Control para agregar items
        
        // Convierte las claves del HashMap a ArrayList para acceso por índice
        ArrayList<String> nombresProductos = new ArrayList<>(menuPizzeria.keySet());
        
        while (continuarItems) { // Bucle para agregar productos
            mostrarMenuProductos(); // Muestra opciones disponibles
            int opcionProducto = leerEntero("Seleccione un producto (1-" + nombresProductos.size() + "): ");
            
            // Valida que la opción esté en rango
            if (opcionProducto < 1 || opcionProducto > nombresProductos.size()) {
                System.out.println("Producto inválido. Por favor seleccione una opción válida.");
                continue; // Vuelve al inicio del bucle
            }
            
            // Obtiene el producto seleccionado usando HashMap
            String nombreProducto = nombresProductos.get(opcionProducto - 1); // Nombre del producto
            double precio = menuPizzeria.get(nombreProducto); // Precio desde HashMap (¡AQUÍ SE USA!)
            
            // Solicita cantidad
            int cantidad = leerEntero("Ingrese la cantidad: ");
            
            // Valida cantidad positiva
            if (cantidad <= 0) {
                System.out.println("La cantidad debe ser mayor a 0.");
                continue; // Vuelve al inicio del bucle
            }
            
            // Crea y agrega el item al pedido
            ItemPedido item = new ItemPedido(nombreProducto, precio, cantidad);
            pedido.agregarItem(item);
            
            // Confirma que se agregó el producto
            System.out.println("Producto agregado: " + cantidad + "x " + nombreProducto);
            
            // Pregunta si desea agregar más productos
            continuarItems = preguntarSiNo("¿Desea agregar otro producto a este pedido? (s/n): ");
        }
        
        return pedido; // Devuelve el pedido completo
    }
    
    /**
     * MÉTODO buscarCliente - Busca un cliente existente por nombre
     * Retorna el cliente si lo encuentra, null si no existe
     */
    private static Cliente buscarCliente(String nombre) {
        // Recorre todos los clientes registrados
        for (Cliente cliente : clientes) {
            // Compara nombres ignorando mayúsculas/minúsculas
            if (cliente.getNombre().equalsIgnoreCase(nombre)) {
                return cliente; // Devuelve el cliente encontrado
            }
        }
        return null; // No se encontró el cliente
    }
    
    /**
     * MÉTODO mostrarComanda - Muestra la comanda (orden de cocina) de un pedido
     * Es la versión simplificada para cocina
     */
    private static void mostrarComanda(Cliente cliente, Pedido pedido) {
        System.out.println("\n=== COMANDA ===");
        System.out.println("Cliente: " + cliente.getNombre());     // Nombre del cliente
        System.out.println("Pedido #" + pedido.getNumeroPedido()); // Número del pedido
        System.out.println("------------------------");
        
        // Lista cada item del pedido (solo cantidad y producto)
        for (ItemPedido item : pedido.getItems()) {
            System.out.println(item.getCantidad() + "x " + item.getNombreProducto());
        }
        System.out.println("------------------------");
    }
    
    /**
     * MÉTODO mostrarFactura - Genera y muestra la factura detallada del pedido
     * Incluye precios, subtotales y total final
     */
    private static void mostrarFactura(Cliente cliente, Pedido pedido) {
        System.out.println("\n=== FACTURA ===");
        System.out.println("PIZZERÍA COMA RICO");                  // Nombre del negocio
        System.out.println("Cliente: " + cliente.getNombre());     // Cliente
        System.out.println("Pedido #" + pedido.getNumeroPedido()); // Número de pedido
        System.out.println("===================================================================");
        
        // Header de la tabla de productos
        System.out.printf("%-25s %5s %10s %12s%n", "PRODUCTO", "CANTIDAD", "PRECIO", "SUBTOTAL");
        System.out.println("===================================================================");
        
        // Detalle de cada producto en el pedido
        for (ItemPedido item : pedido.getItems()) {
            // Imprime: nombre, cantidad, precio unitario, subtotal
            System.out.printf("%-25s %5d $%,9.0f $%,10.0f%n",
                item.getNombreProducto(), // Nombre del producto
                item.getCantidad(),       // Cantidad
                item.getPrecio(),         // Precio unitario
                item.getSubtotal());      // Subtotal (precio * cantidad)
        }
        
        System.out.println("================================");
        // Total final del pedido
        System.out.printf("%-41s $%,10.0f%n", "TOTAL:", pedido.getTotal());
        System.out.println("================================");
        System.out.println("Gracias por su compra!");
    }
    
    /**
     * MÉTODO mostrarVentaTotalDiaria - Genera reporte de ventas totales del día
     * Suma todos los pedidos de todos los clientes
     */
    private static void mostrarVentaTotalDiaria() {
        double ventaTotal = 0;   // Acumulador de dinero total
        int totalPedidos = 0;    // Contador de pedidos totales
        
        // Recorre todos los clientes
        for (Cliente cliente : clientes) {
            ventaTotal += cliente.getTotalCliente(); // Suma dinero del cliente
            totalPedidos += cliente.getPedidos().size(); // Suma pedidos del cliente
        }
        
        // Muestra el resumen
        System.out.println("\n=== RESUMEN VENTA DIARIA ===");
        System.out.println("Total de clientes atendidos: " + clientes.size());
        System.out.println("Total de pedidos realizados: " + totalPedidos);
        System.out.printf("Venta total del dia: $%,.0f%n", ventaTotal); // Formato con comas
    }
    
    /**
     * MÉTODO mostrarVentasPorPizza - Genera reporte de ventas por tipo de pizza
     * Usa HashMap para categorizar y sumar ventas por producto
     */
    private static void mostrarVentasPorPizza() {
        // HashMap para almacenar ventas por pizza (nombre -> total vendido)
        HashMap<String, Double> ventasPorPizza = new HashMap<>();
        // HashMap para almacenar cantidades por pizza (nombre -> cantidad total)
        HashMap<String, Integer> cantidadPorPizza = new HashMap<>();
        
        // Inicializar contadores para cada pizza del menú
        for (String nombreProducto : menuPizzeria.keySet()) { // Recorre productos del menú
            if (nombreProducto.contains("Pizza")) { // Solo si es pizza
                ventasPorPizza.put(nombreProducto, 0.0);  // Inicializa ventas en 0
                cantidadPorPizza.put(nombreProducto, 0);  // Inicializa cantidad en 0
            }
        }
        
        // Calcular ventas reales por pizza
        for (Cliente cliente : clientes) {           // Recorre cada cliente
            for (Pedido pedido : cliente.getPedidos()) { // Recorre cada pedido del cliente
                for (ItemPedido item : pedido.getItems()) {  // Recorre cada item del pedido
                    String nombreProducto = item.getNombreProducto();
                    if (nombreProducto.contains("Pizza")) { // Solo procesa pizzas
                        // Acumula el dinero vendido de esta pizza
                        ventasPorPizza.put(nombreProducto, 
                            ventasPorPizza.get(nombreProducto) + item.getSubtotal());
                        // Acumula la cantidad vendida de esta pizza
                        cantidadPorPizza.put(nombreProducto,
                            cantidadPorPizza.get(nombreProducto) + item.getCantidad());
                    }
                }
            }
        }
        
        // Muestra el reporte
        System.out.println("\n=== VENTAS POR TIPO DE PIZZA ===");
        System.out.printf("%-30s %10s %15s%n", "TIPO DE PIZZA", "CANTIDAD", "VALOR VENDIDO");
        System.out.println("===============================================================");
        
        // Imprime cada pizza con sus totales
        for (String nombrePizza : ventasPorPizza.keySet()) {
            System.out.printf("%-30s %10d $%,13.0f%n", 
                nombrePizza,                              // Nombre de la pizza
                cantidadPorPizza.get(nombrePizza),        // Cantidad total vendida
                ventasPorPizza.get(nombrePizza));         // Dinero total generado
        }
    }
    
    /**
     * MÉTODO mostrarHistorialClientes - Muestra historial completo de todos los clientes
     * Lista cada cliente con sus pedidos y totales
     */
    private static void mostrarHistorialClientes() {
        // Verifica si hay clientes registrados
        if (clientes.isEmpty()) {
            System.out.println("\nNo hay clientes registrados.");
            return; // Sale del método
        }
        
        System.out.println("\n=== HISTORIAL DE CLIENTES ===");
        // Recorre cada cliente registrado
        for (Cliente cliente : clientes) {
            System.out.println("\nCliente: " + cliente.getNombre());                    
            System.out.println("Total de pedidos: " + cliente.getPedidos().size());    
            System.out.printf("Total gastado: $%,.0f%n", cliente.getTotalCliente());   
            
            // Muestra cada pedido individual del cliente
            for (Pedido pedido : cliente.getPedidos()) {
                System.out.println("  Pedido #" + pedido.getNumeroPedido() + 
                    " - Total: $" + String.format("%,.0f", pedido.getTotal()));
            }
        }
    }
    
    /**
     * MÉTODO AUXILIAR leerEntero - Lee un número entero con validación
     * Maneja errores de formato y repite hasta obtener entrada válida
     */
    private static int leerEntero(String mensaje) {
        while (true) { // Bucle infinito hasta obtener entrada válida
            try {
                System.out.print(mensaje);           // Muestra el mensaje
                return Integer.parseInt(read.nextLine()); // Lee y convierte a entero
            } catch (NumberFormatException e) {      // Si no es un número válido
                System.out.println("Por favor ingrese un número válido."); // Error
                // Continúa el bucle para intentar de nuevo
            }
        }
    }
    
    /**
     * MÉTODO AUXILIAR preguntarSiNo - Maneja preguntas de confirmación (sí/no)
     * Valida que la respuesta sea 's'/'si' o 'n'/'no'
     */
    private static boolean preguntarSiNo(String mensaje) {
        while (true) { // Bucle hasta obtener respuesta válida
            System.out.print(mensaje);    // Muestra el mensaje directamente
            String respuesta = read.nextLine().toLowerCase(); 
            switch (respuesta) {
                case "s", "si" -> {
                    return true;
                }
                case "n", "no" -> {
                    return false;
                }
                default ->
                    System.out.println("Por favor responda 's' para sí o 'n' para no.");
            }
        }
    }
}