package com.mycompany.algoritmonomina;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Sistema de cálculo de nómina para departamento de ventas
 * @author Luis Grandett
 */

// Clase para representar un empleado
class Empleado {
    private String nombre;
    private int tipo; // 1 o 2
    private double salarioBasico;
    private double valorVentas;
    private double bonoTransporte;
    private double comision;
    private double salarioTotal;
    
    // Constructor
    public Empleado(String nombre, int tipo, double salarioBasico, double valorVentas) {
        this.nombre = nombre;
        this.tipo = tipo;
        this.salarioBasico = salarioBasico;
        this.valorVentas = valorVentas;
        this.bonoTransporte = 220000; // Fijo para todos
        this.comision = calcularComision();
        this.salarioTotal = salarioBasico + bonoTransporte + comision;
    }
    
    // Método para calcular comisión según tipo y ventas
    private double calcularComision() {
        double porcentajeComision = 0;
        
        if (tipo == 1) {
            if (valorVentas >= 20000000) {
                porcentajeComision = 0.03; // 3%
            } else if (valorVentas >= 10000000) {
                porcentajeComision = 0.05; // 5%
            }
        } else if (tipo == 2) {
            if (valorVentas >= 20000000) {
                porcentajeComision = 0.06; // 6%
            } else if (valorVentas >= 10000000) {
                porcentajeComision = 0.08; // 8%
            }
        }
        
        return valorVentas * porcentajeComision;
    }
    
    // Getters
    public String getNombre() { return nombre; }
    public int getTipo() { return tipo; }
    public double getSalarioBasico() { return salarioBasico; }
    public double getValorVentas() { return valorVentas; }
    public double getBonoTransporte() { return bonoTransporte; }
    public double getComision() { return comision; }
    public double getSalarioTotal() { return salarioTotal; }
    
    // Método para mostrar información del empleado
    public void mostrarInfo() {
        System.out.println("- " + nombre + " (Tipo " + tipo + ")");
        System.out.printf("  Salario Basico: $%,.0f%n", salarioBasico);
        System.out.printf("  Bono Transporte: $%,.0f%n", bonoTransporte);
        System.out.printf("  Ventas: $%,.0f%n", valorVentas);
        System.out.printf("  Comision: $%,.0f%n", comision);
        System.out.printf("  TOTAL: $%,.0f%n", salarioTotal);
        System.out.println();
    }
}


public class AlgoritmoNomina {
    
    private static Scanner read = new Scanner(System.in);
    private static ArrayList<Empleado> empleados = new ArrayList<>();
    private static String periodo;
    
    public static void main(String[] args) {
        System.out.println("================================================================");
        System.out.println("            SISTEMA DE NOMINA - DEPARTAMENTO DE VENTAS         ");
        System.out.println("================================================================");
        System.out.println();
        
        capturarPeriodo();
        capturarEmpleados();
        mostrarResultados();
        
        read.close();
    }
    
    // Método para capturar el período de pago
    private static void capturarPeriodo() {
        System.out.print("Ingrese el periodo de pago (ej: Enero 2025): ");
        periodo = read.nextLine();
        System.out.println();
    }
    
    // Método para capturar datos de empleados
    private static void capturarEmpleados() {
        System.out.println("CAPTURA DE DATOS DE EMPLEADOS");
        System.out.println("-".repeat(50));
        
        String continuar = "s";
        int contador = 1;
        
        while (continuar.equalsIgnoreCase("s")) {
            System.out.println("\nEMPLEADO #" + contador);
            System.out.println("-".repeat(20));
            
            // Capturar nombre
            System.out.print("Nombre: ");
            String nombre = read.nextLine();
            
            // Capturar tipo de empleado
            int tipo;
            do {
                System.out.print("Tipo de empleado (1 o 2): ");
                tipo = read.nextInt();
                if (tipo != 1 && tipo != 2) {
                    System.out.println("Error: Debe ser 1 o 2");
                }
            } while (tipo != 1 && tipo != 2);
            
            // Capturar salario básico
            System.out.print("Salario basico mensual: $");
            double salarioBasico = read.nextDouble();
            
            // Capturar valor de ventas
            System.out.print("Valor total de ventas: $");
            double valorVentas = read.nextDouble();
            
            // Crear empleado y agregarlo a la lista
            Empleado empleado = new Empleado(nombre, tipo, salarioBasico, valorVentas);
            empleados.add(empleado);
            
            System.out.println("Empleado registrado exitosamente");
            
            // Preguntar si continuar
            read.nextLine(); 
            System.out.print("\n¿Desea agregar otro empleado? (s/n): ");
            continuar = read.nextLine();
            
            contador++;
        }
    }
    
    // Método para mostrar todos los resultados
    private static void mostrarResultados() {
        System.out.println("\n\n================================================================");
        System.out.println("                        REPORTE DE NOMINA                      ");
        System.out.println("================================================================");
        
        System.out.println("Periodo: " + periodo);
        System.out.println("Total de trabajadores: " + empleados.size());
        System.out.println();
        
        // Mostrar información detallada de cada empleado
        mostrarDetalleEmpleados();
        
        // Mostrar resúmenes por tipo
        mostrarResumenPorTipo();
        
        // Mostrar totales generales
        mostrarTotalesGenerales();
    }
    
    // Método para mostrar detalle de cada empleado
    private static void mostrarDetalleEmpleados() {
        System.out.println("DETALLE POR EMPLEADO");
        System.out.println("-".repeat(50));
        
        for (Empleado empleado : empleados) {
            empleado.mostrarInfo();
        }
    }
    
    // Método para mostrar resumen por tipo de empleado
    private static void mostrarResumenPorTipo() {
        System.out.println("RESUMEN POR TIPO DE EMPLEADO");
        System.out.println("-".repeat(50));
        
        // Contadores y totales por tipo
        int cantidadTipo1 = 0, cantidadTipo2 = 0;
        double totalTipo1 = 0, totalTipo2 = 0;
        
        // Calcular totales por tipo
        for (Empleado empleado : empleados) {
            if (empleado.getTipo() == 1) {
                cantidadTipo1++;
                totalTipo1 += empleado.getSalarioTotal();
            } else {
                cantidadTipo2++;
                totalTipo2 += empleado.getSalarioTotal();
            }
        }
        
        // Mostrar resultados
        if (cantidadTipo1 > 0) {
            System.out.println("TIPO 1:");
            System.out.println("  Cantidad de empleados: " + cantidadTipo1);
            System.out.printf("  Total pagado: $%,.0f%n", totalTipo1);
            System.out.println();
        }
        
        if (cantidadTipo2 > 0) {
            System.out.println("TIPO 2:");
            System.out.println("  Cantidad de empleados: " + cantidadTipo2);
            System.out.printf("  Total pagado: $%,.0f%n", totalTipo2);
            System.out.println();
        }
    }
    
    // Método para mostrar totales generales
    private static void mostrarTotalesGenerales() {
        double totalGeneral = 0;
        double totalSalariosBasicos = 0;
        double totalBonos = 0;
        double totalComisiones = 0;
        
        // Calcular totales
        for (Empleado empleado : empleados) {
            totalGeneral += empleado.getSalarioTotal();
            totalSalariosBasicos += empleado.getSalarioBasico();
            totalBonos += empleado.getBonoTransporte();
            totalComisiones += empleado.getComision();
        }
        
        System.out.println("TOTALES GENERALES");
        System.out.println("------------------------------------------------------------");
        System.out.printf("Total Salarios Basicos: $%,.0f%n", totalSalariosBasicos);
        System.out.printf("Total Bonos Transporte: $%,.0f%n", totalBonos);
        System.out.printf("Total Comisiones: $%,.0f%n", totalComisiones);
        System.out.println("--------------------------------------------");
        System.out.printf("GRAN TOTAL A PAGAR: $%,.0f%n", totalGeneral);
        
        System.out.println("\nNomina generada exitosamente para " + empleados.size() + 
                          " trabajadores del periodo " + periodo);
    }
}