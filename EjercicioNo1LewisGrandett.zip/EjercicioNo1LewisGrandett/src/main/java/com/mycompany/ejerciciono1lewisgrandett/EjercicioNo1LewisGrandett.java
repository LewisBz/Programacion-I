package com.mycompany.ejerciciono1lewisgrandett;
/**
 * Sistema de Matrículas - Programación Estructurada
 * El sistema es un menu que registrar, actualizar, eliminar y visualizar los datos
 * de un curso de ingles
 * Usando List interface para flexibilidad
 * @author Luis Grandett
 */
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class EjercicioNo1LewisGrandett {
    
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        
        // Usando La interfaz de List - facil cambiar a LinkedList, Vector, etc.
        //Usar la interfaz List y luego la implementacion de Arraylist
        List<String> identificaciones = new ArrayList<>();
        List<String> nombres = new ArrayList<>();
        List<String> fechasNacimiento = new ArrayList<>();
        List<String> direcciones = new ArrayList<>();
        List<String> telefonos = new ArrayList<>();
        List<String> nivelesIngles = new ArrayList<>();
        
        // Declaracion de Variables
        int opcion;
        String tempId, tempNombre, tempFecha, tempDireccion, tempTelefono, tempNivel;
        String respuesta, confirmacion;
        int indiceEncontrado, i;
        boolean encontrado;
        
        // === BUCLE PRINCIPAL ===
        //Use un do while porque el programa se va a ejecutar al menos una vez 
        //y se sale cuando se selecciona la opcion 0
        do {
            // Mostrar menú
            System.out.println("\n=== SISTEMA DE MATRICULAS ===");
            System.out.println("1. Registrar estudiante");
            System.out.println("2. Actualizar datos de estudiante");
            System.out.println("3. Eliminar estudiante o dato");
            System.out.println("4. Mostrar todos los estudiantes");
            System.out.println("0. Salir");
            System.out.print("Seleccione opcion: ");
            
            opcion = read.nextInt();
            read.nextLine();
            
            // === OPCIÓN 1: REGISTRAR ESTUDIANTE ===
            switch (opcion) {
                case 1 -> {
                    System.out.println("\n--- REGISTRAR ESTUDIANTE ---");
                    System.out.print("Identificacion: ");
                    tempId = read.nextLine();
                    // Verificar si ya existe (buscar en la Lista de Identificaciones)
                    encontrado = false;
                    for(i = 0; i < identificaciones.size(); i++) {
                        if(identificaciones.get(i).equals(tempId)) {
                            encontrado = true;
                            break;
                        }
                    }   if(encontrado) {
                        System.out.println("Ya existe un estudiante con esa identificacion");
                    } else {
                        System.out.print("Nombre: ");
                        tempNombre = read.nextLine();
                        
                        //=== Ingresar y leer Fecha nacimiento ===
                        System.out.print("Ingresar fecha nacimiento DD/MM/YY: ");
                        tempFecha = read.nextLine();
                        
                        //=== Ingresar y leer Direccion del estudiante ===
                        System.out.print("Ingresar Direccion de  residencia: ");
                        tempDireccion = read.nextLine();
                        
                        // === Ingresar y leer el telefono ===
                        System.out.print("Ingresar Telefono: ");
                        tempTelefono = read.nextLine();
                        
                        
                       // === Submenu para seleccionar el nivel de Ingles del estudiante
                            System.out.println("Seleccione el nivel de ingles:");
                            System.out.println("1. Principiante A1");
                            System.out.println("2. Principiante A2");
                            System.out.println("3. Intermedio B1");
                            System.out.println("4. Intermedio B2");
                            System.out.println("5. Avanzado C1");
                            System.out.println("6. Avanzado C2");
                            System.out.print("Seleccione opcion (1-6): ");
                            
                            int nivelOpcion = read.nextInt();
                            read.nextLine();
                            
                            switch (nivelOpcion) {
                                case 1 -> tempNivel = "Principiante A1";
                                case 2 -> tempNivel = "Principiante A2";
                                case 3 -> tempNivel = "Intermedio B1";
                                case 4 -> tempNivel = "Intermedio B2";
                                case 5 -> tempNivel = "Avanzado C1";
                                case 6 -> tempNivel = "Avanzado C2";
                                default -> {
                                    System.out.println("Opcion invalida. Asignando Principiante A1 por defecto");
                                    tempNivel = "Principiante A1";
                                }
                            }
                        
                        
                        // Agregar las variables temporales a todas las List (mismo índice = mismo estudiante)
                        identificaciones.add(tempId);
                        nombres.add(tempNombre);
                        fechasNacimiento.add(tempFecha);
                        direcciones.add(tempDireccion);
                        telefonos.add(tempTelefono);
                        nivelesIngles.add(tempNivel);
                        
                        System.out.println("Estudiante registrado exitosamente!");
                    }
                }
                case 2 -> {
                    System.out.println("\n--- ACTUALIZAR ESTUDIANTE ---");
                    if(identificaciones.isEmpty()) {
                        System.out.println("No hay estudiantes registrados");
                    } else {
                        System.out.print("Ingrese ID del estudiante: ");
                        tempId = read.nextLine();
                        
                        // Buscar estudiante de la ArrayList de Identificacion
                        indiceEncontrado = -1;
                        for(i = 0; i < identificaciones.size(); i++) {
                            if(identificaciones.get(i).equals(tempId)) {
                                indiceEncontrado = i;
                                break;
                            }
                        }
                        
                        if(indiceEncontrado == -1) {
                            System.out.println("Estudiante no encontrado");
                        } else {
                            // Mostrar datos actuales
                            System.out.println("Datos actuales:");
                            System.out.println("ID: " + identificaciones.get(indiceEncontrado) +
                                    " | Nombre: " + nombres.get(indiceEncontrado) +
                                    " | Nacimiento: " + fechasNacimiento.get(indiceEncontrado) +
                                    " | Dirección: " + direcciones.get(indiceEncontrado) +
                                    " | Telefono: " + telefonos.get(indiceEncontrado) +
                                    " | Nivel: " + nivelesIngles.get(indiceEncontrado));
                            
                            System.out.println("\n¿Qué desea actualizar?");
                            System.out.println("1. Nombre");
                            System.out.println("2. Fecha de nacimiento");
                            System.out.println("3. Dirección");
                            System.out.println("4. Telefono");
                            System.out.println("5. Nivel de inglés");
                            System.out.print("Seleccione opción: ");
                            
                            int opcionUpdate = read.nextInt();
                            read.nextLine();
                            // ===switch case para actualizar los dato escogido
                            //segun la variable OpcionUpdate===
                            switch (opcionUpdate) {
                                case 1 -> {
                                    System.out.print("Nuevo nombre: ");
                                    nombres.set(indiceEncontrado, read.nextLine());
                                }
                                case 2 -> {
                                    System.out.print("Nueva fecha de nacimiento: ");
                                    fechasNacimiento.set(indiceEncontrado, read.nextLine());
                                }
                                case 3 -> {
                                    System.out.print("Nueva direccion: ");
                                    direcciones.set(indiceEncontrado, read.nextLine());
                                }
                                case 4 -> {
                                    System.out.print("Nuevo telefono: ");
                                    telefonos.set(indiceEncontrado, read.nextLine());
                                }
                                case 5 -> {
                                    System.out.println("Seleccione el nuevo nivel de ingles:");
                                    System.out.println("1. Principiante A1");
                                    System.out.println("2. Principiante A2");
                                    System.out.println("3. Intermedio B1");
                                    System.out.println("4. Intermedio B2");
                                    System.out.println("5. Avanzado C1");
                                    System.out.println("6. Avanzado C2");
                                    System.out.print("Seleccione opción (1-6): ");
                                    int nivelOpcion = read.nextInt();
                                    read.nextLine();
                                    
                                    switch (nivelOpcion) {
                                        case 1 -> nivelesIngles.set(indiceEncontrado, "Principiante A1");
                                        case 2 -> nivelesIngles.set(indiceEncontrado, "Principiante A2");
                                        case 3 -> nivelesIngles.set(indiceEncontrado, "Intermedio B1");
                                        case 4 -> nivelesIngles.set(indiceEncontrado, "Intermedio B2");
                                        case 5 -> nivelesIngles.set(indiceEncontrado, "Avanzado C1");
                                        case 6 -> nivelesIngles.set(indiceEncontrado, "Avanzado C2");
                                        default -> {
                                            System.out.println("Opcion invalida");
                                            continue;}
                                    }
                                }
                                default -> {
                                    System.out.println("Opcion invalida");
                                    continue;
                                }
                            }
                            
                            System.out.println("Datos actualizados!");
                        }
                    }
                }
                case 3 -> {
                    System.out.println("\n--- ELIMINAR ---");
                    if(identificaciones.isEmpty()) {
                        System.out.println("No hay estudiantes registrados");
                    } else {
                        System.out.print("Ingrese ID del estudiante: ");
                        tempId = read.nextLine();
                        
                        // Buscar estudiante
                        indiceEncontrado = -1;
                        for(i = 0; i < identificaciones.size(); i++) {
                            if(identificaciones.get(i).equals(tempId)) {
                                indiceEncontrado = i;
                                break;
                            }
                        }
                        
                        if(indiceEncontrado == -1) {
                            System.out.println("Estudiante no encontrado");
                        } else {
                            // Mostrar datos del estudiante
                            System.out.println("Datos del estudiante:");
                            System.out.println("ID: " + identificaciones.get(indiceEncontrado) +
                                    " | Nombre: " + nombres.get(indiceEncontrado) +
                                    " | Nacimiento: " + fechasNacimiento.get(indiceEncontrado) +
                                    " | Dirección: " + direcciones.get(indiceEncontrado) +
                                    " | Telefono: " + telefonos.get(indiceEncontrado) +
                                    " | Nivel: " + nivelesIngles.get(indiceEncontrado));
                            
                            // Submenu de eliminacion
                            System.out.println("\n¿Qué desea eliminar?");
                            System.out.println("1. TODO el estudiante (eliminar completamente)");
                            System.out.println("2. Solo un dato específico (vaciar campo)");
                            System.out.print("Seleccione opcion: ");
                            
                            int tipoEliminacion = read.nextInt();
                            read.nextLine();
                            
                            switch (tipoEliminacion) {
                                case 1 -> {
                                    // ELIMINAR ESTUDIANTE COMPLETO
                                    System.out.print("¿Está seguro de eliminar TODO el estudiante? (s/n): ");
                                    confirmacion = read.nextLine();
                                    if(confirmacion.equalsIgnoreCase("s")) {
                                        identificaciones.remove(indiceEncontrado);
                                        nombres.remove(indiceEncontrado);
                                        fechasNacimiento.remove(indiceEncontrado);
                                        direcciones.remove(indiceEncontrado);
                                        telefonos.remove(indiceEncontrado);
                                        nivelesIngles.remove(indiceEncontrado);
                                        
                                        System.out.println("Estudiante eliminado completamente!");
                                    } else {
                                        System.out.println("Eliminacion cancelada");
                                    }
                                }
                                case 2 -> {
                                    // ELIMINAR DATO EN ESPECIFICO
                                    System.out.println("\n¿Qué dato desea eliminar?");
                                    System.out.println("1. Fecha de nacimiento");
                                    System.out.println("2. Direccion");
                                    System.out.println("3. Telefono");
                                    System.out.println("4. Nivel de inglés (volver a Principiante A1)");
                                    System.out.print("Seleccione el dato a eliminar: ");
                                    int datoEliminar = read.nextInt();
                                    read.nextLine();
                                    switch (datoEliminar) {
                                        case 1 -> {
                                            fechasNacimiento.set(indiceEncontrado, "No registrado");
                                            System.out.println("Fecha de nacimiento eliminada");
                                        }
                                        case 2 -> {
                                            direcciones.set(indiceEncontrado, "No registrada");
                                            System.out.println("Dirección eliminada");
                                        }
                                        case 3 -> {
                                            telefonos.set(indiceEncontrado, "No registrado");
                                            System.out.println("Telefono eliminado");
                                        }
                                        case 4 -> {
                                            nivelesIngles.set(indiceEncontrado, "Principiante A1");
                                            System.out.println("Nivel de inglés restablecido a Principiante A1");
                                        }
                                        default -> System.out.println("Opcion invalida");
                                    }
                                }
                                default -> System.out.println("Opcion invalida");
                            }
                        }
                    }
                }
                case 4 -> {
                    System.out.println("\n--- LISTA DE ESTUDIANTES ---");
                    if(identificaciones.isEmpty()) {
                        System.out.println("No hay estudiantes registrados");
                    } else {
                        System.out.println("Total de estudiantes: " + identificaciones.size());
                        System.out.println();
                        
                        for(i = 0; i < identificaciones.size(); i++) {
                            System.out.println((i + 1) + ". ID: " + identificaciones.get(i) +
                                    " | Nombre: " + nombres.get(i) +
                                    " | Nacimiento: " + fechasNacimiento.get(i) +
                                    " | Direccion: " + direcciones.get(i) +
                                    " | Telefono: " + telefonos.get(i) +
                                    " | Nivel: " + nivelesIngles.get(i));
                        }
                    }
                }
                case 0 -> System.out.println("Saliendo del Sistema");
                default -> System.out.println("Opcion invalida");
            }
            
        } while(opcion != 0);
        
        read.close();
    }
}