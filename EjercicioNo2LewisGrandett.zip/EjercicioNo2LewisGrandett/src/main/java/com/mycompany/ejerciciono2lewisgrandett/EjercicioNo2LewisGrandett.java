package com.mycompany.ejerciciono2lewisgrandett;

import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

// Clase simplificada para insumos dentro del producto
class InsumoProducto {
    String nombreInsumo;
    double cantidadRequerida;
    double precioUnitario;
    
    public double getCostoTotal() {
        return cantidadRequerida * precioUnitario;
    }
}

// Clase principal del producto
class Product {
    String id;
    String nombreProducto;
    String descripcion;
    List<InsumoProducto> insumos;
    
    //constructor
    public Product() {
        this.insumos = new ArrayList<>();
    }
    
    // Calcular costo de producción/fabricación (suma de todos los insumos)
    public double calcularCostoProduccion() {
        double total = 0;
        //for each para recorrer los elementos de la lista
        for (InsumoProducto insumo : insumos) {
            total += insumo.getCostoTotal();
        }
        return total;
    }
    
    // Calcular costo de venta según canal Online/Fisico
    public double calcularCostoVenta(String canal) {
        double costoProduccion = calcularCostoProduccion();
        if (canal.equalsIgnoreCase("Online")) {
            return costoProduccion * 1.28; // +28%
        } else if (canal.equalsIgnoreCase("Tienda")) {
            return costoProduccion * 1.35; // +35%
        }
        return costoProduccion;
    }
}

public class EjercicioNo2LewisGrandett {
    static Scanner read = new Scanner(System.in);
    static List<Product> products = new ArrayList<>();
    
    public static void main(String[] args) {
        int opcion = 0; // variable para seleccionar las opciones del switch case principal(Menu) y a su vez para el bucle do while
        
        System.out.println("=========================================================");
        System.out.println("                    MUEBLES JAMAR                       ");
        System.out.println("        Sistema de Control de Costos de Produccion      ");
        System.out.println("=========================================================");
        System.out.println("              Gestion Inteligente de Inventario         ");
        System.out.println("---------------------------------------------------------");
        
        do {
            
            System.out.println("---------------------------------------------------------");
            System.out.println("                         MENU                           ");
            System.out.println("---------------------------------------------------------");
            System.out.println("1. Crear Producto Completo");
            System.out.println("2. Mostrar Costos de Produccion");
            System.out.println("3. Mostrar Costos de Venta por Canal");
            System.out.println("4. Mostrar Todos los Productos");
            System.out.println("0. Salir");
            System.out.println("---------------------------------------------------------");
            System.out.print("Seleccione una opcion (0-4): ");
            opcion = read.nextInt();
            read.nextLine();
            
            System.out.println("Opcion Seleccionada: " + opcion);
            
            switch (opcion) {
                case 1 -> crearProductoCompleto();
                case 2 -> mostrarCostosProduccion();
                case 3 -> mostrarCostosVenta();
                case 4 -> mostrarProductos();
                case 0 -> System.out.println("Gracias por usar el sistema!");
                default -> System.out.println("Opcion invalida. Intente nuevamente.");
            }
            
        } while (opcion != 0);
    }
   
    // Método principal: crear producto completo con sus insumos
    public static void crearProductoCompleto() {
        System.out.println("\n=== CREAR PRODUCTO COMPLETO ===");
        
        Product producto = new Product();
        
        // Datos básicos del producto
        System.out.print("Ingrese ID del producto: ");
        producto.id = read.nextLine();
        
        // Verificar ID único
        if (buscarProductoPorId(producto.id) != null) {
            System.out.println("ERROR: Ya existe un producto con este ID.");
            return;
        }
        
        System.out.print("Ingrese nombre del producto: ");
        producto.nombreProducto = read.nextLine();
        
        System.out.print("Ingrese descripcion del producto: ");
        producto.descripcion = read.nextLine();
        
        // Crear insumos para el producto
        System.out.print("Cuantos insumos requiere este producto? ");
        int cantidadInsumos = read.nextInt();
        read.nextLine();
        
        for (int i = 0; i < cantidadInsumos; i++) {
            System.out.println("\n--- Insumo " + (i + 1) + " ---");
            
            InsumoProducto insumo = new InsumoProducto();
            
            System.out.print("Nombre del insumo: ");
            insumo.nombreInsumo = read.nextLine();
            
            System.out.print("Cantidad requerida: ");
            insumo.cantidadRequerida = read.nextDouble();
            
            System.out.print("Precio unitario: $");
            insumo.precioUnitario = read.nextDouble();
            read.nextLine();
            
            producto.insumos.add(insumo);
            
            System.out.println("Costo de este insumo: $" + 
                String.format("%.2f", insumo.getCostoTotal()));
        }
        
        products.add(producto);
        
        // Mostrar resumen del producto creado
        System.out.println("\n=== PRODUCTO CREADO EXITOSAMENTE ===");
        System.out.println("ID: " + producto.id);
        System.out.println("Nombre: " + producto.nombreProducto);
        System.out.println("Descripción: " + producto.descripcion);
        System.out.println("Costo de Producción: $" + 
            String.format("%.2f", producto.calcularCostoProduccion()));
    }
    
    // Mostrar costos de producción de todos los productos
    public static void mostrarCostosProduccion() {
        if (products.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }
        
        System.out.println("\n=== COSTOS DE PRODUCCION/FABRICACION ===");
        
        for (Product producto : products) {
            System.out.println("-----------------------------------------");
            System.out.println("Producto: " + producto.nombreProducto + " (ID: " + producto.id + ")");
            System.out.println("Costo Total: $" + 
                String.format("%.2f", producto.calcularCostoProduccion()));
            
            System.out.println("Detalle de insumos:");
            for (InsumoProducto insumo : producto.insumos) {
                System.out.println("  - " + insumo.nombreInsumo + 
                    " | Cantidad: " + insumo.cantidadRequerida + 
                    " | Precio Unit: $" + insumo.precioUnitario + 
                    " | Subtotal: $" + String.format("%.2f", insumo.getCostoTotal()));
            }
        }
    }
    
    // Mostrar costos de venta por canal de venta específico (Fisico-Online)
    public static void mostrarCostosVenta() {
        if (products.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }
        
        // Mostrar productos disponibles
        System.out.println("\n=== PRODUCTOS DISPONIBLES ===");
        for (Product p : products) {
            System.out.println("ID: " + p.id + " - " + p.nombreProducto);
        }
        
        System.out.print("\nIngrese ID del producto: ");
        String productId = read.nextLine();
        
        Product producto = buscarProductoPorId(productId);
        if (producto == null) {
            System.out.println("Producto no encontrado.");
            return;
        }
        
        System.out.println("\n=== SELECCIONAR CANAL DE VENTA ===");
        System.out.println("1. Online (+28%)");
        System.out.println("2. Tienda/Físico (+35%)");
        System.out.print("Seleccione canal (1-2): ");
        int opcion = read.nextInt();
        read.nextLine();
        
        String canal = (opcion == 1) ? "Online" : "Tienda";
        double porcentaje = (opcion == 1) ? 28.0 : 35.0;
        
        double costoProduccion = producto.calcularCostoProduccion();
        double costoVenta = producto.calcularCostoVenta(canal);
        double margen = costoVenta - costoProduccion;
        
        System.out.println("\n=== RESULTADO COSTOS DE VENTA ===");
        System.out.println("Producto: " + producto.nombreProducto);
        System.out.println("Canal: " + canal);
        System.out.println("Costo de Producción: $" + String.format("%.2f", costoProduccion));
        System.out.println("Precio de Venta: $" + String.format("%.2f", costoVenta));
        System.out.println("Margen de Ganancia: $" + String.format("%.2f", margen));
        System.out.println("Incremento aplicado: " + porcentaje + "%");
    }
    
    // Mostrar todos los productos con información completa
    public static void mostrarProductos() {
        if (products.isEmpty()) {
            System.out.println("No hay productos registrados.");
            return;
        }
        
        System.out.println("\n=== INVENTARIO COMPLETO ===");
        
        for (Product producto : products) {
            System.out.println("=========================================");
            System.out.println("ID: " + producto.id);
            System.out.println("Producto: " + producto.nombreProducto);
            System.out.println("Descripción: " + producto.descripcion);
            System.out.println("Insumos registrados: " + producto.insumos.size());
            
            double costoProduccion = producto.calcularCostoProduccion();
            System.out.println("\n--- COSTOS ---");
            System.out.println("Producción/Fabricación: $" + String.format("%.2f", costoProduccion));
            System.out.println("Venta Online: $" + String.format("%.2f", producto.calcularCostoVenta("Online")));
            System.out.println("Venta Tienda: $" + String.format("%.2f", producto.calcularCostoVenta("Tienda")));
            
            System.out.println("\n--- MÁRGENES DE GANANCIA ---");
            System.out.println("Margen Online: $" + String.format("%.2f", 
                producto.calcularCostoVenta("Online") - costoProduccion));
            System.out.println("Margen Tienda: $" + String.format("%.2f", 
                producto.calcularCostoVenta("Tienda") - costoProduccion));
        }
    }
    
    // Método auxiliar para buscar producto por ID
    public static Product buscarProductoPorId(String id) {
        for (Product producto : products) {
            if (producto.id.equals(id)) {
                return producto;
            }
        }
        return null;
    }
}